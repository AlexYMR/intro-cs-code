/**
 * A program to test out Dessert, Cake, BirthdayCake, and IceCream
 * Demonstrates polymorphism using an abstract class
 */
public class DessertTest
{
   public static void main(String[] args)
   {
      Dessert[] dArray = new Dessert[3];
      dArray[0] = new Cake(6);
      dArray[1] = new BirthdayCake(8, 4);
      dArray[2] = new IceCream(4, "chocolate");

      for(Dessert d : dArray)
      {
	 System.out.println(d);
	 d.eat();
      }
   }
}
