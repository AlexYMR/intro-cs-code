/**
 * Represents a BirthdayCake (a Cake with candles)
 * Demonstrating inheritance/polymorphism
 * See also: Dessert.java, Cake.java, IceCream.java, CakeTest.java, DessertTest.java
 */
public class BirthdayCake extends Cake
{
   /**
    * The number of candles on the cake.
    */
   private int numCandles;
   
   /**
    * Constructor
    * @param numSlices int, represents the initial number of slices of cake
    * @param numCandles int, represents the number of candles on the cake
    */
   public BirthdayCake(int numSlices, int numCandles)
   {
      super(numSlices);
      this.numCandles = numCandles;
   }

   public int getNumCandles()
   {
      return numCandles;
   }
   
   @Override
   public String toString()
   {
      return super.toString() + " Happy Birthday!";
   }
}
