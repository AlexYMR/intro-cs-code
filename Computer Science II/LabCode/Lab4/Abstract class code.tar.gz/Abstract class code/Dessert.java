/**
 * An abstract class representing the abstract concept of "dessert"
 * Demonstrating inheritance/polymorphism
 * See also: Cake.java, BirthdayCake.java, IceCream.java, CakeTest.java, DessertTest.java
 */
public abstract class Dessert
{
   /**
    * Eat the dessert
    * Reduces the amount of dessert and prints a message.
    * @return void
    */
   public abstract void eat();
}
