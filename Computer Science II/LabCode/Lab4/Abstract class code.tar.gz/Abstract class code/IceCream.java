/**
 * Represents ice cream.
 * Demonstrating inheritance/polymorphism
 * See also: Dessert.java, Cake.java, BirthdayCake.java, CakeTest.java, DessertTest.java
 */
public class IceCream extends Dessert
{
   private int numScoops;
   private String flavor;
   
   /**
    * Constructor
    * @param numScoops int, represents the initial number of scoops of ice cream
    * @param flavor String, the name of the flavor of ice cream
    */
   public IceCream(int numScoops, String flavor)
   {
      this.numScoops = numScoops;
      this.flavor = flavor;
   }

   public int getNumScoops()
   {
      return numScoops;
   }

   public String getFlavor()
   {
      return flavor;
   }

   /**
    * If there are some scoops left, reduces the number by one.
    * Either way, prints a message.
    * @return void
    */
   @Override
   public void eat()
   {
      if(numScoops > 0)
      {
	 System.out.println("You eat some delicious " + flavor + " ice cream.");
	 numScoops -= 1;
      }
      else
      {
	 System.out.println("There is no more ice cream :-(");
      }      
   }

   @Override
   public String toString()
   {
      return "It's ice cream.";
   }   
}
