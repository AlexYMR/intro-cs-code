/**
 * An abstract class representing the abstract concept of "dessert"
 * Demonstrating inheritance/polymorphism
 *
 * This one differs from Dessert.java because it also has 
 * some concrete methods.
 * You might also adjust Cake, BirthdayCake, etc. to call these
 * two concrete methods.
 *
 * See also: Cake.java, BirthdayCake.java, IceCream.java, CakeTest.java, DessertTest.java
 */
public abstract class Dessert
{
    protected int gramSugar;

    public void setSugar(int sugar)
    {
	gramSugar = sugar;
    }
    
    public int getSugar()
    {
	return gramSugar;
    }
    
   /**
    * Eat the dessert
    * Reduces the amount of dessert and prints a message.
    * @return void
    */
   public abstract void eat();
}
