/**
 * Represents a Cake
 * Demonstrating inheritance/polymorphism
 * See also: Dessert.java, BirthdayCake.java, IceCream.java, CakeTest.java, DessertTest.java
 */
public class Cake extends Dessert
{
   /**
    * The number of remaining slices of cake.
    */
   protected int numSlices;

   /**
    * Constructor
    * @param numSlices int, represents the initial number of slices of cake
    */
   public Cake(int numSlices)
   {
      this.numSlices = numSlices;
   }

   public int getNumSlices()
   {
      return numSlices;
   }

   /**
    * If there are some slices left, reduces the number by one.
    * Either way, prints a message.
    * @return void
    */
   @Override
   public void eat()
   {
      if(numSlices > 0)
      {
	 System.out.println("You eat a delicious slice of cake.");
	 numSlices -= 1;
      }
      else
      {
	 System.out.println("There is no more cake :-(");
      }
   }

   @Override
   public String toString()
   {
      return "It's a cake.";
   }
}
